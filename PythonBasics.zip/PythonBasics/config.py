import os
from dotenv import load_dotenv

# Cargar variables de entorno
load_dotenv()

# Configuración del bot
DISCORD_TOKEN = os.getenv('DISCORD_TOKEN')

# Prefijo para comandos
PREFIX = '!'

# Mensajes de error
ERROR_MESSAGES = {
    'translation_failed': '❌ Error al traducir el mensaje. Por favor, inténtalo de nuevo.',
    'invalid_text': '❌ Por favor, proporciona un texto para traducir.',
    'language_detection_failed': '❌ No se pudo detectar el idioma del texto.',
    'service_unavailable': '❌ El servicio de traducción no está disponible en este momento.',
}

# Mensajes informativos
INFO_MESSAGES = {
    'help': '''🔤 **Comandos disponibles:**
    - `!ayuda`: Muestra este mensaje de ayuda

    El bot detectará automáticamente si el texto está en español o italiano y lo traducirá al otro idioma.
    Simplemente escribe tu mensaje y el bot responderá con la traducción.''',
    'translating': '🔄 Traduciendo...',
    'ready': '✅ Bot de traducción español-italiano listo!',
}

# Códigos de idioma
LANGUAGES = {
    'es': 'español',
    'it': 'italiano'
}