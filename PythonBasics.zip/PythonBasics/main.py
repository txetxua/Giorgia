import discord
from discord.ext import commands
from config import DISCORD_TOKEN, ERROR_MESSAGES, INFO_MESSAGES
from translator import TranslationService
from utils import setup_logger, validate_input

# Configuración inicial
logger = setup_logger()
intents = discord.Intents.default()
intents.message_content = True  # Necesario para leer mensajes
intents.guilds = True  # Necesario para unirse a servidores
bot = commands.Bot(command_prefix="!", intents=intents)
translator = TranslationService()

@bot.event
async def on_ready():
    """Evento que se dispara cuando el bot está listo"""
    logger.info("Bot iniciado correctamente")
    logger.info(f"Conectado como {bot.user.name}")
    logger.info(f"ID del bot: {bot.user.id}")
    logger.info(f"Conectado a {len(bot.guilds)} servidores:")
    for guild in bot.guilds:
        logger.info(f"- {guild.name} (id: {guild.id})")
    print(INFO_MESSAGES['ready'])

@bot.event
async def on_connect():
    """Evento que se dispara cuando el bot se conecta a Discord"""
    logger.info("Bot conectado a Discord")

@bot.event
async def on_disconnect():
    """Evento que se dispara cuando el bot se desconecta de Discord"""
    logger.error("Bot desconectado de Discord")

@bot.event
async def on_error(event, *args, **kwargs):
    """Maneja errores generales del bot"""
    logger.error(f"Error en evento {event}: {str(args)} {str(kwargs)}")

@bot.event
async def on_guild_join(guild):
    """Evento que se dispara cuando el bot se une a un nuevo servidor"""
    logger.info(f"¡Bot añadido a un nuevo servidor! Nombre: {guild.name} (ID: {guild.id})")
    # Encontrar el primer canal donde podamos enviar mensajes
    for channel in guild.text_channels:
        try:
            await channel.send(INFO_MESSAGES['help'])
            break
        except:
            continue

@bot.event
async def on_message(message):
    """Procesa cada mensaje para traducción automática"""
    # Ignorar mensajes del propio bot
    if message.author == bot.user:
        return

    # Ignorar comandos
    if message.content.startswith('!'):
        await bot.process_commands(message)
        return

    # Validar el mensaje
    if not validate_input(message.content):
        return

    try:
        # Realizar traducción
        logger.info(f"Procesando mensaje: {message.content[:50]}...")
        result = translator.translate_text(message.content)

        # Enviar solo la traducción como respuesta
        await message.reply(result["translated"], mention_author=False)
        logger.info("Mensaje traducido y enviado correctamente")

    except ValueError as e:
        logger.error(f"Error de traducción: {str(e)}")
        await message.reply(str(e), mention_author=False)
    except Exception as e:
        logger.error(f"Error inesperado: {str(e)}")
        await message.reply(ERROR_MESSAGES['service_unavailable'], mention_author=False)

@bot.command(name='ayuda')
async def help_command(ctx):
    """Comando para mostrar la ayuda"""
    await ctx.send(INFO_MESSAGES['help'])

@bot.event
async def on_command_error(ctx, error):
    """Manejador global de errores de comandos"""
    if isinstance(error, commands.CommandNotFound):
        return

    logger.error(f"Error en comando: {str(error)}")
    await ctx.send(ERROR_MESSAGES['service_unavailable'])

def main():
    """Función principal para iniciar el bot"""
    while True:
        try:
            logger.info("Iniciando el bot...")
            logger.info(f"Token length: {len(DISCORD_TOKEN) if DISCORD_TOKEN else 0}")
            if not DISCORD_TOKEN:
                logger.error("Token de Discord no encontrado o vacío")
                raise ValueError("Token de Discord no encontrado o vacío")
            bot.run(DISCORD_TOKEN, log_handler=None, reconnect=True)
        except Exception as e:
            logger.error(f"Error al iniciar el bot: {str(e)}")
            print("Intentando reconectar en 30 segundos...")
            import time
            time.sleep(30)

if __name__ == "__main__":
    main()