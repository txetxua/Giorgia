from googletrans import Translator
from config import LANGUAGES, ERROR_MESSAGES
import logging

class TranslationService:
    def __init__(self):
        self.translator = Translator()
        self.logger = logging.getLogger(__name__)

    def detect_language(self, text: str) -> str:
        """Detecta el idioma del texto (español o italiano)"""
        try:
            self.logger.info(f"Detectando idioma del texto: {text[:50]}...")
            detection = self.translator.detect(text)
            detected_lang = detection.lang
            self.logger.info(f"Idioma detectado: {detected_lang}")

            if detected_lang in ['es', 'it']:
                return detected_lang
            # Si no es español ni italiano, asumimos español por defecto
            return 'es'
        except Exception as e:
            self.logger.error(f"Error en detección de idioma: {str(e)}")
            raise ValueError(ERROR_MESSAGES['language_detection_failed'])

    def translate_text(self, text: str) -> dict:
        """Traduce el texto entre español e italiano"""
        try:
            self.logger.info("Iniciando proceso de traducción")
            source_lang = self.detect_language(text)
            target_lang = 'it' if source_lang == 'es' else 'es'

            self.logger.info(f"Traduciendo de {source_lang} a {target_lang}")
            translation = self.translator.translate(
                text,
                src=source_lang,
                dest=target_lang
            )

            result = {
                'original': text,
                'translated': translation.text,
                'source_lang': source_lang,
                'target_lang': target_lang
            }
            self.logger.info("Traducción completada exitosamente")
            return result

        except Exception as e:
            self.logger.error(f"Error en traducción: {str(e)}")
            raise ValueError(ERROR_MESSAGES['translation_failed'])