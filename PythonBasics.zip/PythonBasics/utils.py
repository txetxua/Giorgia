import logging
from datetime import datetime

# Configuración del sistema de logging
def setup_logger():
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(f'bot_log_{datetime.now().strftime("%Y%m%d")}.log', encoding='utf-8'),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger(__name__)

# Función para validar el texto de entrada
def validate_input(text: str) -> bool:
    if not text or len(text.strip()) == 0:
        return False
    return True

# Función para formatear la respuesta de traducción
def format_translation_response(original: str, translated: str, source_lang: str, target_lang: str) -> str:
    return f'> {original}\n{translated}'