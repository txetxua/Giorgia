import discord
import speech_recognition as sr
from googletrans import Translator
import asyncio
import logging
import numpy as np
import pyaudio
from config import ERROR_MESSAGES
import wave
import io

class VoiceTranslator:
    def __init__(self, bot):
        self.bot = bot
        self.translator = Translator()
        self.recognizer = sr.Recognizer()
        self.voice_clients = {}
        self.logger = logging.getLogger(__name__)
        self.recording = False

        # Configuración de audio
        self.CHANNELS = 1
        self.RATE = 16000
        self.CHUNK = 1024
        self.FORMAT = pyaudio.paInt16
        self.SILENCE_THRESHOLD = 0.015

        try:
            # Inicializar PyAudio
            self.audio = pyaudio.PyAudio()
            self.logger.info("PyAudio inicializado correctamente")

            # Configurar el dispositivo de audio virtual
            self.setup_virtual_audio_device()

        except Exception as e:
            self.logger.error(f"Error al inicializar el audio: {str(e)}")
            raise

    def setup_virtual_audio_device(self):
        """Configura un dispositivo de audio virtual si no hay dispositivos físicos"""
        try:
            # Obtener información de los dispositivos
            info = self.audio.get_host_api_info_by_index(0)
            numdevices = info.get('deviceCount', 0)
            self.logger.info(f"Número de dispositivos encontrados: {numdevices}")

            # Buscar un dispositivo de entrada válido
            self.input_device_index = None
            for i in range(numdevices):
                device_info = self.audio.get_device_info_by_index(i)
                self.logger.info(f"Dispositivo {i}: {device_info.get('name')}")

                if device_info.get('maxInputChannels', 0) > 0:
                    self.input_device_index = i
                    self.logger.info(f"Usando dispositivo de entrada: {device_info.get('name')}")
                    break

            if self.input_device_index is None:
                # Si no hay dispositivo físico, usar el dispositivo virtual
                self.input_device_index = 0
                self.logger.warning("No se encontró dispositivo de entrada físico, usando dispositivo virtual")

            # Verificar si el dispositivo seleccionado funciona
            test_stream = self.audio.open(
                format=self.FORMAT,
                channels=self.CHANNELS,
                rate=self.RATE,
                input=True,
                input_device_index=self.input_device_index,
                frames_per_buffer=self.CHUNK,
                start=False
            )
            test_stream.close()

            self.logger.info("Configuración de audio inicializada correctamente")

        except Exception as e:
            self.logger.error(f"Error al configurar el dispositivo de audio: {str(e)}")
            raise

    async def join_voice_channel(self, voice_channel):
        """Une el bot al canal de voz"""
        try:
            if voice_channel.guild.voice_client:
                await voice_channel.guild.voice_client.disconnect()

            voice_client = await voice_channel.connect()
            self.voice_clients[voice_channel.guild.id] = voice_client
            self.logger.info(f"Bot unido al canal de voz: {voice_channel.name}")
            return voice_client
        except Exception as e:
            self.logger.error(f"Error al unirse al canal de voz: {str(e)}")
            return None

    async def leave_voice_channel(self, guild_id):
        """Desconecta el bot del canal de voz"""
        try:
            if guild_id in self.voice_clients:
                if self.recording:
                    self.stop_recording()
                await self.voice_clients[guild_id].disconnect()
                del self.voice_clients[guild_id]
                self.logger.info(f"Bot desconectado del canal de voz en el servidor {guild_id}")
                return True
            return False
        except Exception as e:
            self.logger.error(f"Error al desconectar del canal de voz: {str(e)}")
            return False

    def stop_recording(self):
        """Detiene la grabación de audio"""
        self.recording = False
        self.logger.info("Grabación de audio detenida")

    async def process_audio(self, voice_client, text_channel):
        """Procesa el audio y muestra subtítulos traducidos"""
        if not voice_client or not voice_client.is_connected():
            await text_channel.send("❌ No estoy conectado a un canal de voz.")
            return

        try:
            self.recording = True
            self.audio_buffer = bytearray()

            # Configurar y abrir el stream de audio
            stream = self.audio.open(
                format=self.FORMAT,
                channels=self.CHANNELS,
                rate=self.RATE,
                input=True,
                input_device_index=self.input_device_index,
                frames_per_buffer=self.CHUNK
            )

            stream.start_stream()
            self.logger.info(f"Stream de audio iniciado con dispositivo index: {self.input_device_index}")
            await text_channel.send("✅ Comenzando a escuchar...")

            while self.recording and voice_client.is_connected():
                try:
                    data = stream.read(self.CHUNK, exception_on_overflow=False)
                    if data:
                        await self.process_audio_chunk(voice_client, data)
                except IOError as e:
                    self.logger.warning(f"Error de lectura de audio (ignorando): {str(e)}")
                    continue

                await asyncio.sleep(0.1)

        except Exception as e:
            error_msg = f"Error en el procesamiento de audio: {str(e)}"
            self.logger.error(error_msg)
            self.logger.error(f"Configuración actual: device={self.input_device_index}, rate={self.RATE}, channels={self.CHANNELS}")
            await text_channel.send(f"❌ {error_msg}")
        finally:
            if 'stream' in locals():
                stream.stop_stream()
                stream.close()
            self.recording = False
            self.logger.info("Grabación de audio detenida")

    async def process_audio_chunk(self, voice_client, audio_data):
        """Procesa un fragmento de audio"""
        try:
            # Convertir audio a formato WAV
            with io.BytesIO() as wav_io:
                with wave.open(wav_io, 'wb') as wav_file:
                    wav_file.setnchannels(self.CHANNELS)
                    wav_file.setsampwidth(self.audio.get_sample_size(self.FORMAT))
                    wav_file.setframerate(self.RATE)
                    wav_file.writeframes(audio_data)

                wav_io.seek(0)
                with sr.AudioFile(wav_io) as source:
                    audio = self.recognizer.record(source)

            # Intentar reconocer en español e italiano
            text = None
            try:
                text = self.recognizer.recognize_google(audio, language='es-ES')
                target_lang = 'it'
                self.logger.info(f"Texto reconocido en español: {text}")
            except:
                try:
                    text = self.recognizer.recognize_google(audio, language='it-IT')
                    target_lang = 'es'
                    self.logger.info(f"Texto reconocido en italiano: {text}")
                except Exception as e:
                    return  # Si no se reconoce el audio, simplemente continuamos

            if text:
                # Traducir el texto reconocido
                translation = self.translator.translate(
                    text,
                    src='es' if target_lang == 'it' else 'it',
                    dest=target_lang
                ).text

                # Enviar la traducción
                await voice_client.channel.send(translation)
                self.logger.info(f"Audio procesado y traducido exitosamente")

        except Exception as e:
            self.logger.error(f"Error en el procesamiento de audio: {str(e)}")
            # No propagamos el error para continuar el proceso de grabación